package com.example.labweek5;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import androidx.drawerlayout.widget.DrawerLayout;
public class MainActivity extends AppCompatActivity {

    ArrayList<String> myList = new ArrayList<String>();

    ArrayAdapter myAdapter;
    DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.drawer);

        ListView listView = findViewById(R.id.bookList);
        myAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1 , myList);
        listView.setAdapter(myAdapter);

        ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.SEND_SMS, android.Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS}, 0);
        MyBroadcastReceiver myBroadCastReceiver = new MyBroadcastReceiver();
        registerReceiver(myBroadCastReceiver, new IntentFilter(SMSReceiver.SMS_FILTER));

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawerLayout = findViewById(R.id.dl);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        FloatingActionButton fab = findViewById(R.id.floatingActionButton);

        NavigationView navigationView = findViewById(R.id.navigationMenu);
        navigationView.setNavigationItemSelectedListener(new MyDrawerListener());

        Log.i("lab3", "onCreate");
    }

    protected void onStart(){
        super.onStart();
        SharedPreferences myData = getSharedPreferences("f1", 0);
        String id = myData.getString("id","");
        String title = myData.getString("title","");
        String isbn = myData.getString("isbn","");
        String description = myData.getString("description","");
        String author = myData.getString("author","");
        String price = myData.getString("price","");

        EditText Title = findViewById(R.id.Title);
        EditText Price = findViewById(R.id.Price);
        EditText ID = findViewById(R.id.ID);
        EditText ISBN = findViewById(R.id.ISBN);
        EditText Author = findViewById(R.id.Author);
        EditText Description = findViewById(R.id.Description);

        if (!id.equals("")){
            ID.setText(id);
        }
        if (!title.equals("")){
            Title.setText(title);
        }
        if (!isbn.equals("")){
            ISBN.setText(isbn);
        }
        if (!description.equals("")){
            Description.setText(description);
        }
        if (!author.equals("")){
            Author.setText(author);
        }
        if (!price.equals("")){
            Price.setText(price);
        }

        Log.i("lab3", "onStart");
    }

    protected void onPause(){
        super.onPause();
        Log.i("lab3", "onPause");
    }

    protected void onResume(){
        super.onResume();
        Log.i("lab3", "onResume");
    }

    //    @Override
    protected void onStop() {
        super.onStop();

        EditText Title = findViewById(R.id.Title);
        EditText Price = findViewById(R.id.Price);
        EditText ID = findViewById(R.id.ID);
        EditText ISBN = findViewById(R.id.ISBN);
        EditText Author = findViewById(R.id.Author);
        EditText Description = findViewById(R.id.Description);

        SharedPreferences myData = getSharedPreferences("f1", 0);
        SharedPreferences.Editor myEditor = myData.edit();
        myEditor.putString("title", Title.getText().toString());
        myEditor.putString("price", Price.getText().toString());
        myEditor.putString("id", ID.getText().toString());
        myEditor.putString("isbn", ISBN.getText().toString());
        myEditor.putString("author", Author.getText().toString());
        myEditor.putString("description", Description.getText().toString());
        myEditor.commit();

        Log.i("lab3", "onStop");
    }

    protected void onDestroy(){
        super.onDestroy();
        Log.i("lab3", "onDestroy");
    }


    public void nextActivity(View v){
//        Intent myIntent = new Intent(this, MainActivity2.class);
//        startActivity(myIntent);
    }

    public void loadLast(View v){
        SharedPreferences myData = getSharedPreferences("f1", 0);
        String id = myData.getString("id","");
        String title = myData.getString("title","");
        String isbn = myData.getString("isbn","");
        String description = myData.getString("description","");
        String author = myData.getString("author","");
        String price = myData.getString("price","");

        EditText Title = findViewById(R.id.Title);
        EditText Price = findViewById(R.id.Price);
        EditText ID = findViewById(R.id.ID);
        EditText ISBN = findViewById(R.id.ISBN);
        EditText Author = findViewById(R.id.Author);
        EditText Description = findViewById(R.id.Description);

        if (!id.equals("")){
            ID.setText(id);
        }
        if (!title.equals("")){
            Title.setText(title);
        }
        if (!isbn.equals("")){
            ISBN.setText(isbn);
        }
        if (!description.equals("")){
            Description.setText(description);
        }
        if (!author.equals("")){
            Author.setText(author);
        }
        if (!price.equals("")){
            Price.setText(price);
        }

    }

    public void addToast(View v){
        EditText Title = findViewById(R.id.Title);
        EditText Price = findViewById(R.id.Price);
        String output = Title.getText().toString() + " ($" + Price.getText().toString() +") " +"is added";
//        Toast myMessage = Toast.makeText(this , output, Toast.LENGTH_SHORT);
        Snackbar myMessage = Snackbar.make(v, output, Snackbar.LENGTH_LONG).setAction("undo", undoListener);
        myMessage.show();

        EditText ID = findViewById(R.id.ID);
        EditText ISBN = findViewById(R.id.ISBN);
        EditText Author = findViewById(R.id.Author);
        EditText Description = findViewById(R.id.Description);

        SharedPreferences myData = getSharedPreferences("f1", 0);
        SharedPreferences.Editor myEditor = myData.edit();
        myEditor.putString("title", Title.getText().toString());
        myEditor.putString("price", Price.getText().toString());
        myEditor.putString("id", ID.getText().toString());
        myEditor.putString("isbn", ISBN.getText().toString());
        myEditor.putString("author", Author.getText().toString());
        myEditor.putString("description", Description.getText().toString());
        myEditor.commit();

        myList.add(Title.getText() + " | " + Price.getText());
        myAdapter.notifyDataSetChanged();
    }

    View.OnClickListener undoListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            myList.remove(myList.size()-1);
            myAdapter.notifyDataSetChanged();
        }
    };




    public void clearFields(View v){
        EditText Title = findViewById(R.id.Title);
        EditText ID = findViewById(R.id.ID);
        EditText ISBN = findViewById(R.id.ISBN);
        EditText Price = findViewById(R.id.Price);
        EditText Author = findViewById(R.id.Author);
        EditText Description = findViewById(R.id.Description);
        Title.getText().clear();
        ID.getText().clear();
        ISBN.getText().clear();
        Price.getText().clear();
        Author.getText().clear();
        Description.getText().clear();
        Toast myMessage = Toast.makeText(this , "Fields are cleared!", Toast.LENGTH_SHORT);
        myMessage.show();
    }

    public void doublePrice(View v){
        EditText Price = findViewById(R.id.Price);
        int amount = 2 * Integer.parseInt(Price.getText().toString());
        Price.setText(Integer.toString(amount));
    }

    public void isbnChange(View v){
        SharedPreferences myData = getSharedPreferences("f1", 0);
        SharedPreferences.Editor myEditor = myData.edit();
        myEditor.putString("isbn", "00112233");
        myEditor.commit();
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
//        super.onRestoreInstanceState(savedInstanceState);
        String title = savedInstanceState.getString("Title");
        String isbn = savedInstanceState.getString("ISBN");
        EditText Title = findViewById(R.id.Title);
        EditText ISBN = findViewById(R.id.ISBN);
        if (!title.equals("")){
            Title.setText(title);
        }
        if (!isbn.equals("")){
            ISBN.setText(isbn);
        }
        EditText ID = findViewById(R.id.ID);
        EditText Price = findViewById(R.id.Price);
        EditText Author = findViewById(R.id.Author);
        EditText Description = findViewById(R.id.Description);
        ID.getText().clear();
        Price.getText().clear();
        Author.getText().clear();
        Description.getText().clear();
        Log.i("lab3", "onRestore");
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
//        super.onSaveInstanceState(outState);
        EditText Title = findViewById(R.id.Title);
        EditText ISBN = findViewById(R.id.ISBN);
        outState.putString("Title", Title.getText().toString());
        outState.putString("ISBN",ISBN.getText().toString() );
        Log.i("lab3", "onSave");
    }

    class MyBroadcastReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            /*
             * Retrieve the message from the intent
             * */
            String msg = intent.getStringExtra(SMSReceiver.SMS_MSG_KEY);
            /*
             * String Tokenizer is used to parse the incoming message
             * The protocol is to have the account holder name and account number separate by a semicolon
             * */

            StringTokenizer sT = new StringTokenizer(msg, "|");
            String id = sT.nextToken();
            String title = sT.nextToken();
            String isbn = sT.nextToken();
            String author = sT.nextToken();
            String description = sT.nextToken();
            String price = sT.nextToken();
            int priceINT = Integer.parseInt(price);
            String priceBool = sT.nextToken();
            boolean price_boolean = Boolean.parseBoolean(priceBool);

            EditText Title = findViewById(R.id.Title);
            EditText Price = findViewById(R.id.Price);
            EditText ID = findViewById(R.id.ID);
            EditText ISBN = findViewById(R.id.ISBN);
            EditText Author = findViewById(R.id.Author);
            EditText Description = findViewById(R.id.Description);

            ID.setText(id);
            Title.setText(title);
            ISBN.setText(isbn);
            Author.setText(author);
            Description.setText(description);
            Price.setText(price);

            if (price_boolean){
                Price.setText(Integer.toString(priceINT + 100));
            }
            else{
                Price.setText(Integer.toString(priceINT + 5));
            }

            Log.i("lab4", "SMS");
        }
    }
    class MyDrawerListener implements NavigationView.OnNavigationItemSelectedListener{

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            int id = item.getItemId();

            if (id == R.id.addMenu) {
                addToast(findViewById(R.id.floatingActionButton));

            } else if (id == R.id.removeLast) {
                if (myList.size() > 0){
                    myList.remove(myList.size()-1);
                    myAdapter.notifyDataSetChanged();
                }
            }
            else if(id == R.id.clearMenu){
                if (myList.size() > 0){
                    myList.clear();
                    myAdapter.notifyDataSetChanged();
                }
            }
            else if(id == R.id.closeApp){
                finish();
            }
            // close the drawer
            drawerLayout.closeDrawers();
            // tell the OS
            return true;
        }
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options,menu);

        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.clearOptions) {
            clearFields(null);
        } else if (id == R.id.loadData) {
            loadLast(null);
        }
        else if(id == R.id.totalBooks){
            String output = myList.size() + " Books";
            Toast myMessage = Toast.makeText(this , output, Toast.LENGTH_SHORT);
            myMessage.show();
        }
        // close the drawer

        // tell the OS
        return true;
//        return super.onOptionsItemSelected(item);
    }
}